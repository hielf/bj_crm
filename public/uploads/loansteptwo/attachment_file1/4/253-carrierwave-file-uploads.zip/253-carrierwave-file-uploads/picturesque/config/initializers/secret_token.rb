# Be sure to restart your server when you modify this file.

# Your secret key for verifying the integrity of signed cookies.
# If you change this key, all old signed cookies will become invalid!
# Make sure the secret is at least 30 characters and all random,
# no regular words or you'll be exposed to dictionary attacks.
Picturesque::Application.config.secret_token = 'c520158abe2e6b4b0e2632098bb522dcf492c3b1facd48e499475541424269c1327d56b8a16d1755fd8dadbf6983f6e9b46b6f69cc692d92d021aa64b0fb376d'
