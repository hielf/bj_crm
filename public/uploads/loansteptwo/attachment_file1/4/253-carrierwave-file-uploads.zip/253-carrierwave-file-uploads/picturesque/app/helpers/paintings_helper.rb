module PaintingsHelper
end
